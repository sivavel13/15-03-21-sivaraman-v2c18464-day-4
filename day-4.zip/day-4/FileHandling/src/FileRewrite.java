import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class FileRewrite {

	public static void main(String[] args) {
		
		try {
			FileWriter startWrite = new FileWriter("C:\\Users\\sivv2c18464\\Desktop\\filehandling.txt");
			startWrite.write("File handling simple concept but it is very important and powerful!");
			startWrite.close();
			System.out.println("Successfully add that line");
		} catch (IOException e) {
			System.out.println("error occured");
			e.printStackTrace();
		}

	}

}
