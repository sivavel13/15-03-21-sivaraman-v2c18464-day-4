
import java.io.File;
import java.io.FileWriter;

public class WriteInNewFile {

	public static void main(String[] args) {
		File file=new File("C:\\Users\\sivv2c18464\\Desktop\\filehandling.txt");
		try {
			if(file.canWrite())
				System.out.println(file.canWrite());
			
			FileWriter filewriter=new FileWriter(file);
			filewriter.write("Learn combintion of filehandling with exception handling is useful upcoming big projects...:)");
			filewriter.close();
			System.out.println("Successfully writted");
		} catch (Exception e) {
			System.out.println("Exception Occured");
			e.printStackTrace();
		}
		
	}
}

