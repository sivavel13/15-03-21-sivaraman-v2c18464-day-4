import java.io.File;
import java.io.IOException;
public class createfile {

	public static void main(String[] args) {
		
	File filehandling = new File("C:\\Users\\sivv2c18464\\Desktop\\filehandling.txt");
	
	try {
			if (filehandling.createNewFile()) {
					System.out.println("File is sucssesfully created" + filehandling.getName());
				
			}
			else {
					System.out.println("File is already created");
			}
	} catch (IOException e) {
		System.out.println("Exception occured");
		e.printStackTrace();
	}
	}

}
