import java.io.File;
import java.io.IOException;

public class DeleteFile {

	public static void main(String[] args) {
		
	File filehandling = new File("C:\\Users\\sivv2c18464\\Desktop\\filehandling.txt");
	try {
		if (filehandling.delete()) {
				System.out.println("File is sucssesfully deleted" + filehandling.getName());
			
		}
		else {
				System.out.println("File is already created");
		}
	} 
	catch (Exception e) {
	System.out.println("Exception occured");
	e.printStackTrace();
	}

	}

}
