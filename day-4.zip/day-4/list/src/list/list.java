package list;
import java.util.ArrayList;

public class list {

	public static void main(String[] args) {
		empdetail();
	}
	
	static void empdetail() {
		
		ArrayList<String> empname = new ArrayList<String>();
		empname.add("Ahkil");
		empname.add("Ananth");
		empname.add("Karthik");
		empname.add("Mani");
		empname.add("Sumit");
		System.out.println(empname);
		empname.set(4, "Maran");
		System.out.println(empname);
		System.out.println(empname.get(3));
		
		for(int i = 0; i < empname.size(); i++ ) 
		{
			System.out.println(empname.get(i));
		}
		
		ArrayList<Integer> empid = new ArrayList<Integer>();
		empid.add(01);
		empid.add(02);
		empid.add(03);
		empid.add(04);
		empid.add(05);
		System.out.println(empid);
		System.out.println(empid.get(3));
		
		for(int i : empid) {
			System.out.println(i);
		}
	}
	
		
		
	}
	
	


